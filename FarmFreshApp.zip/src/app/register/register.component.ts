import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private us: UserService, private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(formRef){
    let userObj=formRef.value;
    //console.log(userObj);
    this.us.createUser(userObj).subscribe(
      res=>{
      if(res["message"]=="New User Added"){
        alert("New user Created Succesfullly")
        this.router.navigateByUrl("/login")
      }
      else{
        alert("User name already present")
        formRef.reset();
      }
      }
    )
  }


}
